<?php
header("Location: http://ispumaps.id/indoorpelindo/");
?>